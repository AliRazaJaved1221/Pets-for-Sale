/* eslint-disable prettier/prettier */
// import { UserRoles } from 'src/auth/constant/constants';
import { Review } from 'src/review/entities/review.entity';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';
@Entity('UserEntity')
export class UserEntity {
  @PrimaryGeneratedColumn()
  id: number;
  @Column()
  username: string;
  @Column()
  email: string;
  @Column()
  password: string;
  @Column()
  createdAt: Date;
  @Column({ nullable: true })
  updatedAt: Date;
  @Column({ nullable: true })
  role: string; // Assuming role is a string, you can change the type as needed
  @OneToMany(() => Review, (review) => review.user)
  reviews: Review[];
}
