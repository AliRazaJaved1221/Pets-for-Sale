/* eslint-disable prettier/prettier */

import { Cats } from 'src/cats/entities/cat.entity';
import { Review } from 'src/review/entities/review.entity';
import { Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from 'typeorm';

@Entity('Pets')
export class Pets {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ nullable: true })
  breed: string;

  @Column({ nullable: true })
  color: string;

  @Column({ nullable: true })
  age: string;

  @Column({ nullable: true })
  price: string;

  @Column({ nullable: true })
  description: string;

  @Column({ nullable: true })
  image: string;

  @Column({ default: false })
  isAlive: boolean;
  // @ManyToOne(() => Todo, (cat) => cat.pets)
  // cat: Todo;
  @ManyToOne(() => Cats, (todo) => todo.pets)
  todo: Cats;

  @OneToMany(() => Review, (review) => review.pet)
  reviews: Review[];
  // @OneToMany(() => Review, (review) => review.pet, {
  //   cascade: true,
  //   onDelete: 'CASCADE',
  // })
  // reviews: Review[];
}
