/* eslint-disable prettier/prettier */
import { HttpException, Injectable } from '@nestjs/common';
import { CreateCatDto } from './dto/create-cat.dto';
import { UpdateCatDto } from './dto/update-cat.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Cats } from './entities/cat.entity';
import { Repository } from 'typeorm';

@Injectable()
export class CatsService {
  constructor(
    @InjectRepository(Cats)
    private readonly catsRepository: Repository<Cats>,
  ) {}
  async create(createCatDto: CreateCatDto): Promise<Cats> {
    const catsInfo = await this.catsRepository.create(createCatDto);
    console.log('catsInfo', catsInfo);
    return this.catsRepository.save(catsInfo);
  }

  async getUsersWithPets(): Promise<Cats[]> {
    return this.catsRepository.find({ relations: ['pets'] });
  }

  // findAll(): Promise<any> {
  //   return this.catsRepository.find();
  // }

  async findOne(id: number): Promise<Cats> {
    const catInfo = await this.catsRepository.findOneBy({ id });
    if (!catInfo) {
      throw new HttpException('Cat Not Found', 404);
    }
    return catInfo;
  }

  async update(id: number, updateTodoDto: UpdateCatDto): Promise<Cats> {
    const existingUser = await this.findOne(id);
    const catInfo = this.catsRepository.merge(existingUser, updateTodoDto);
    return await this.catsRepository.save(catInfo);
  }

  delete(id: string): Promise<any> {
    return this.catsRepository
      .createQueryBuilder()
      .delete()
      .from(Cats)
      .where('id = :id', { id })
      .execute();
  }
}
