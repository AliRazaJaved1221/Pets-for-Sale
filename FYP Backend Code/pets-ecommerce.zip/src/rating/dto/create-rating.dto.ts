export class CreateRatingDto {}
