/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
} from '@nestjs/common';
import { CatsService } from './cats.service';
import { CreateCatDto } from './dto/create-cat.dto';
import { UpdateCatDto } from './dto/update-cat.dto';
import { ApiTags } from '@nestjs/swagger';

@ApiTags('Cats')
@Controller('cats')
export class CatsController {
  constructor(private readonly catsService: CatsService) {}

  @Post('/create')
  async create(@Body() createCatDto: CreateCatDto) {
    try {
      const catsInfo = await this.catsService.create(createCatDto);

      return {
        success: true,
        data: catsInfo,
        message: 'Cat Created Successfully',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('/get')
  async findAll() {
    try {
      const data = await this.catsService.getUsersWithPets();
      return {
        success: true,
        data,
        message: 'Cats Fetched Successfully',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Get('/get/:id')
  async findOne(@Param('id') id: string) {
    try {
      const data = await this.catsService.findOne(+id);
      return {
        success: true,
        data,
        message: 'User Fetched Successfully',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Patch('/update/:id')
  async update(@Param('id') id: string, @Body() updateTodoDto: UpdateCatDto) {
    try {
      await this.catsService.update(+id, updateTodoDto);
      return {
        success: true,
        message: 'User Updated Successfully',
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
      };
    }
  }

  @Delete('delete/:id')
  async remove(@Param('id') id: string) {
    await this.catsService.delete(id);
    return 'cat deleted';
  }
}
