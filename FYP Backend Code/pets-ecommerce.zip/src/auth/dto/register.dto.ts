/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsOptional, IsString } from 'class-validator';

/* eslint-disable prettier/prettier */
export class SignUpDto {
  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'fullName is required' })
  username: string;

  @ApiProperty({
    example: '',
  })
  @IsEmail({}, { message: 'email must be a valid email' })
  @IsNotEmpty({ message: 'email is required' })
  email: string;
  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsOptional()
  @IsNotEmpty({ message: 'password is required' })
  password: string;
  
  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'mobileContact is required' })
  mobileContact: string;

  //   @ApiProperty({
  //     example: [],
  //     type: [Number],
  //   })
  //   @IsOptional()
  //   @IsArray({ message: 'specialities should be an array' })
  //   @IsNumber({}, { each: true })
  //   // @ArrayMinSize(1, { message: 'At least speciality is required' })
  //   specialities: number[];

  //   @ApiProperty({ enum: UserRoles, default: UserRoles.PATIENT })
  //   @IsEnum(UserRoles, { message: 'User role should be one of: Patient, Doctor' })
  //   userRole: UserRoles;
}
