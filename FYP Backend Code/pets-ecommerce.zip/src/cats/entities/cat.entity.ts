/* eslint-disable prettier/prettier */
import { Pets } from 'src/pets/entities/pet.entity';
import { Column, Entity, OneToMany, PrimaryGeneratedColumn } from 'typeorm';

@Entity('Cats')
export class Cats {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ nullable: true })
  breed: string;

  @Column({ default: false })
  isAlive: boolean;

  @OneToMany(() => Pets, (pet) => pet.todo)
  pets: Pets[];
}
