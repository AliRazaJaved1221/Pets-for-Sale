/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreatePetDto {
 

  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'breed is required' })
  @IsOptional()
  breed: string;

  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'color is required' })
  @IsOptional()
  color: string;

  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'age is required' })
  @IsOptional()
  age: string;

  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'price is required' })
  @IsOptional()
  price: string;

  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'description is required' })
  @IsOptional()
  description: string;

  @ApiProperty({
    example: '',
  })
  @IsString()
  // @IsNotEmpty({ message: 'description is required' })
  @IsOptional()
  image: string;

  @ApiProperty({ example: true })
  @IsBoolean()
  @IsNotEmpty({ message: 'isAlive is required' })
  @IsOptional()
  isAlive: boolean;
}
