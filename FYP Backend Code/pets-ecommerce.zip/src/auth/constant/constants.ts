/* eslint-disable prettier/prettier */
export const jwtConstants = {
  secret: 'JWTSecret#@!',
};
export enum UserRoles {
  Admin = 2,
  SuperAdmin = 1,
}