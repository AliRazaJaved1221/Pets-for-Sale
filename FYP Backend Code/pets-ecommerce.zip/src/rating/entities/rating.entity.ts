export class Rating {}
