export class CreateComplainDto {}
