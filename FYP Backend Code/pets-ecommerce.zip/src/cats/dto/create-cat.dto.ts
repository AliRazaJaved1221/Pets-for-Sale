/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNotEmpty, IsOptional, IsString } from 'class-validator';

export class CreateCatDto {
  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'title is required' })
  @IsOptional()
  name: string;

  @ApiProperty({
    example: '',
  })
  @IsString()
  @IsNotEmpty({ message: 'breed is required' })
  @IsOptional()
  breed: string;

  @ApiProperty({ example: true })
  @IsBoolean()
  @IsNotEmpty({ message: 'isAlive is required' })
  @IsOptional()
  isAlive: boolean;
}
